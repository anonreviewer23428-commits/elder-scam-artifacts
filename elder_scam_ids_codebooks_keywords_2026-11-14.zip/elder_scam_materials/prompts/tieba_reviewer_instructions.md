# Independent Reviewer Instructions

You are the second semantic pass for one packet.

1. Read the entire final codebook and the exact labeler schema.
2. Read the packet and its normalized-ground-truth calibration examples.
3. Form your own 15-variable judgments from the title, body, and comments.
4. Only then inspect the matching primary result.
5. Correct every unsupported, missing, over-coded, under-coded, or structurally
   invalid assignment. Do not rubber-stamp the primary result.

The primary corpus audit found frequent cap saturation. Review every selected
label as an independent evidence claim and remove unsupported extras. In
particular:

- five red flags, three responses, four informal-security actions, two emotions,
  or three comment-help functions require unusually dense explicit evidence;
- `Accept Comply`, `Consult`, emotional `Help-Seeking`, comment `Scam Analysis &
  Identification`, and `No Substantive Help` have historically been over-coded;
- one dominant emotion is preferable when the alleged second frame is merely
  implied by topic or purpose;
- do not copy a code from a semantically similar ground-truth example unless the
  assigned row itself contains the evidence;
- do not convert outcome silence into `No (Not Recovered)`, or a family case into
  third-party participation.

Apply the same N/A rules, selection caps, axis rules, and codebook ordering in
`LABELER_INSTRUCTIONS.md`. Pay special attention to:

- purpose: practical advice vs factual verification vs complaint vs public appeal;
- health categories: supplement vs named-disease treatment vs durable device;
- channel identity precedence and the contact/commitment axis split;
- red flags that must be text-evidenced rather than inferred from category;
- initial compliance vs persistence after warning vs outward promotion;
- police/regulator/company/platform actor and outcome distinctions;
- comments: diagnosis vs verification advice vs warning vs recovery vs exit;
- not-recovered vs outcome-unstated;
- family participant vs third-party retelling.

Write one reviewed JSON object per input row, in packet order, to:
`reviewed/packet_NNNN.jsonl`.

Use the same required `row_index`, `source_key`, and `labels` structure as the
primary file. You may add:

```json
"review_meta":{"changed_dimensions":["red_flag"],"uncertain_dimensions":[],"brief_note":""}
```

Run:

```text
python3 Baidu/tieba_codebook_final_labeling_4865_work/validate_result.py reviewed --packet NNNN
```

Fix all failures before finishing.
