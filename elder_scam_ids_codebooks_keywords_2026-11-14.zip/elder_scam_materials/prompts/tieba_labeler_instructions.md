# Primary Labeler Instructions

You are assigning the final Tieba elder-scam codebook to one immutable packet.

## Authority and files

1. Read the entire authoritative codebook before labeling:
   `Baidu/Tieba_Codebook_Final/Tieba_Elder_Scam_Codebook_Final.md`
2. Use the exact machine-readable contract:
   `Baidu/Tieba_Codebook_Final/schema_manifest_final_labeler.json`
3. Read your assigned `packets/packet_NNNN.jsonl`.
4. Read the matching `calibration/packet_NNNN.jsonl`. These are the nearest
   normalized hand-coded examples. Use them as semantic calibration, but the
   final codebook controls if an example is not truly analogous.

Do not edit the source CSV, codebook, schema, packet, calibration file, or
ground-truth files.

## Coding rules

- Judge the title, post body, and captured comments together.
- Assign all 15 variables to every row.
- Use only exact code names from the codebook. Never invent, shorten, translate,
  or paraphrase a code.
- Every value is a nonempty JSON array. Use `["N/A"]` only where permitted and
  only when the codebook's applicability rule is met.
- Respect every selection cap. Do not fill a quota merely because room remains.
- For `contact_to_commitment`, include 1–2 contact-channel codes and 1–3
  commitment codes, with at most 4 combined. Put contact channels first and
  commitments second. Use `["N/A"]` only when there is no route episode at all.
- Put every multi-select array in the order the labels appear in the schema.
- Treat every multi-select cap as a ceiling, never as a target. Default to the
  smallest directly supported set. A category, red flag, response, protective
  action, emotional frame, or comment-help function needs its own literal
  evidence in the row; do not infer it merely from another selected code.
- Five red flags should be exceptional. Do not emit five because a known scam
  type commonly has those features; each flag must be independently evidenced.
- Use one emotional frame unless a second frame is comparably dominant in the
  poster's own title/body. Topic, purpose, and comment tone do not automatically
  create a second emotional frame.
- `Accept Comply` requires an actual elder/household compliance act in the
  narrated incident. A generic news, warning, scheme description, or scammer
  pitch does not establish that response.
- `Consult` requires that the poster actually turns to an online community for
  judgment/advice. Merely publishing a warning, report, or news item is not
  consultation. Likewise, emotional `Help-Seeking` requires a plea-like affect,
  not every practical help or verification request.
- Do not duplicate the same action across several response/security codes unless
  the text independently supports each function. For example, posting a plea to
  Tieba can support `Seek Help & Advice` and `Consult`, but not automatically
  investigation, warning, documentation, or public advocacy.
- For `help_from_comments`, code only functions actually performed by captured
  comments. Absent or unusable comments are `N/A`; observed but unhelpful
  responses are `No Substantive Help`.
- In comment coding, `Scam Analysis & Identification` requires commenters to
  diagnose or explain the specific scheme; a bare "be careful" is only a safety
  warning. `No Substantive Help` is rare and applies only when actual responses
  exist yet none performs even emotional support or another listed function.
- For `loss_recovered`, silence is `Unknown (Outcome Unstated)`, not
  `No (Not Recovered)`. `No` needs affirmative evidence that the loss stands.
- For `participant`, family members describing their own household count as
  `Yes (First-Hand Participant)`; news, neighbors, and strangers are `No`.

## Output

Write exactly one JSON object per input row, in packet order, to:
`primary/packet_NNNN.jsonl`.

Each line must have this shape:

```json
{"row_index":123,"source_key":"tidpid:...","labels":{"scam":["Yes (Scam-Relevant)"],"purpose_of_post":["Help & Advice Seeking"],"category_of_scam":["Investment & Illegal Fundraising"],"promise_or_need":["Investment Gain"],"contact_to_commitment":["Online Groups, Chat & Platform Solicitation","Investment & Deposit"],"asset_extracted":["Money"],"red_flag":["Unrealistic Financial Promise"],"respond":["Seek Help & Advice"],"informal_security_work":["Consult"],"one_off_or_repeated":["Repeated"],"party_intervened":["N/A"],"emotional_frame":["Protective Concern","Help-Seeking"],"participant":["Yes (First-Hand Participant)"],"help_from_comments":["Reporting & Complaint-Channel Advice"],"loss_recovered":["Unknown (Outcome Unstated)"]},"review_meta":{"uncertain_dimensions":[],"brief_note":""}}
```

`review_meta` is optional. If used, keep it short. Do not omit any label key.

After writing, run:

```text
python3 Baidu/tieba_codebook_final_labeling_4865_work/validate_result.py primary --packet NNNN
```

Fix every reported error before declaring the packet complete.

For an oversize single-row packet, inspect the whole body and comments in
manageable chunks. You may delegate comment-function review, but you remain
responsible for one coherent 15-variable result.
