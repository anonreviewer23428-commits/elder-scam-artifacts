# Manager Adjudication Instructions

The primary and independent-review passes are complete before this phase starts.
They are immutable evidence.  A manager owns one entry in
`manager_assignment_manifest.json` and must work only on that entry.

## Evidence order

1. Read the final codebook and schema in full.
2. Read your assignment entry and the cited packet/calibration rows.
3. Inspect the corresponding reviewed labels, `review_meta`, and primary labels.
4. Resolve each assigned dimension from the row text, comments, calibration,
   and final codebook.  Do not defer a listed uncertainty.

The assignment manifest targets every reviewer uncertainty, every row with at
least three primary-to-review dimension changes, and all changed rows in
statistically high-change packets.  Managers may audit extra dimensions on an
assigned target row when a dependency or codebook rule requires it.

## Decision overlay

Never edit `primary/` or `reviewed/`.  Preserve those two independent passes.
Write exactly one JSONL record per assigned target row to
`manager_decisions/manager_NN.jsonl`, using `apply_patch`.  Records must follow:

```json
{
  "manager_id": "manager_NN",
  "packet_id": 0,
  "row_index": 0,
  "source_key": "exact source key",
  "audited_dimensions": ["schema-ordered dimension names"],
  "final_values": {"dimension": ["canonical labels"]},
  "changed_from_review_dimensions": [],
  "resolved_uncertainty_dimensions": [],
  "unresolved_dimensions": [],
  "rationale": "Brief evidence-bounded adjudication rationale."
}
```

- `audited_dimensions` must include every `required_dimensions` item in the
  assignment and remain in schema order.
- `final_values` must have exactly the audited dimensions and use canonical,
  schema-ordered labels.
- `changed_from_review_dimensions` must exactly identify audited dimensions
  whose final value differs from the reviewed value.
- `resolved_uncertainty_dimensions` must exactly identify assigned reviewer
  uncertainties that were resolved.
- `unresolved_dimensions` must be `[]` to finish.
- Never infer facts from a category label; apply the literal evidence and
  dimension-specific codebook gates.

## Manager report

Write `manager_reports/manager_NN.json` with:

Use this exact field set (replace placeholders with assignment-derived values):

```json
{
  "schema_version": "tieba-manager-report-v1",
  "manager_id": "manager_NN",
  "packet_ids": [],
  "decision_file": "Baidu/tieba_codebook_final_labeling_4865_work/manager_decisions/manager_NN.jsonl",
  "decision_file_sha256": "",
  "primary_validation": true,
  "reviewed_validation": true,
  "assigned_target_row_count": 0,
  "decision_row_count": 0,
  "changed_rows_in_assigned_packets": 0,
  "rows_changed_by_manager": 0,
  "reviewer_uncertainty_dimensions_resolved": 0,
  "oversize_packet_ids": [],
  "oversize_handling": "State how assigned oversize packets were read, or say none were assigned.",
  "unresolved_issues": [],
  "notes": ""
}
```

From the repository root, run:

```sh
python3 Baidu/tieba_codebook_final_labeling_4865_work/validate_manager_audit.py \
  --manager manager_NN
```

After the decision JSONL exists, the validator output includes an
`expected_report` object with the exact computed hash and counts.  Copy that
object into the report with `apply_patch`, then rerun the same command.

Only the assigned decision file and report may be created or edited.
